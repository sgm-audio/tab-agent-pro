"""
Tab Agent Pro — Unit Tests: SplitterAgent
Tests for Demucs stem separation and spatial audio processing.
"""

import os

# Add parent directory to path for imports
import sys
import tempfile
import unittest

import numpy as np
import soundfile as sf

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from agents import SplitterAgent


class TestSplitterAgent(unittest.TestCase):
    """Unit tests for SplitterAgent spatial processing logic."""

    def setUp(self) -> None:
        self.tmpdir = tempfile.mkdtemp()
        self.splitter = SplitterAgent(output_dir=self.tmpdir)

    def tearDown(self) -> None:
        import shutil

        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_output_dir_created(self) -> None:
        """Output directory is created on init."""
        assert os.path.isdir(self.splitter.output_dir)

    def test_center_kill_factor_reduces_center(self) -> None:
        """Mid-side processing isolates centre from sides."""
        sr = 44100
        duration = 1.0
        t = np.linspace(0, duration, int(sr * duration), endpoint=False)

        # Create stereo: same signal in both channels (hard centre)
        mono_signal = 0.5 * np.sin(2 * np.pi * 440 * t)
        stereo = np.vstack((mono_signal, mono_signal))

        # Write temp stereo file
        stereo_path = os.path.join(self.tmpdir, "stereo_test.wav")
        sf.write(stereo_path, stereo.T, sr)

        # Process
        result = self.splitter.process_guitars(stereo_path)

        # Read back processed files
        lead, _lead_sr = sf.read(result["lead"])
        rhythm_l, _ = sf.read(result["left"])
        rhythm_r, _ = sf.read(result["right"])

        # Lead (mid) should be stronger than rhythm sides (after centre kill)
        assert np.max(np.abs(lead)) > np.max(np.abs(rhythm_l))
        assert np.max(np.abs(lead)) > np.max(np.abs(rhythm_r))

    def test_process_guitars_returns_correct_keys(self) -> None:
        """process_guitars returns dict with lead, left, right keys."""
        sr = 44100
        stereo = np.random.randn(2, sr).astype(np.float32)
        stereo_path = os.path.join(self.tmpdir, "stereo_test.wav")
        sf.write(stereo_path, stereo.T, sr)

        result = self.splitter.process_guitars(stereo_path)
        assert "lead" in result
        assert "left" in result
        assert "right" in result
        for path in result.values():
            assert os.path.exists(path)

    def test_process_bass_returns_path(self) -> None:
        """process_bass returns a valid file path."""
        sr = 44100
        mono = np.random.randn(sr).astype(np.float32)
        bass_path = os.path.join(self.tmpdir, "bass_test.wav")
        sf.write(bass_path, mono, sr)

        result = self.splitter.process_bass(bass_path)
        assert os.path.exists(result)

    def test_separate_with_subprocess_resolves_extensionless_demucs_dir(self) -> None:
        """_separate_with_subprocess finds Demucs stems under htdemucs/<stem_without_ext>/."""
        from unittest.mock import MagicMock, patch

        # Demucs creates htdemucs/song/ even when song_name is "song.wav"
        demucs_dir = os.path.join(self.tmpdir, "htdemucs", "song")
        os.makedirs(demucs_dir, exist_ok=True)
        for s in ("other", "bass", "drums", "vocals"):
            open(os.path.join(demucs_dir, f"{s}.wav"), "wb").close()

        with patch("agents.subprocess.run", return_value=MagicMock(returncode=0)):
            stems = self.splitter._separate_with_subprocess("/tmp/song.wav", "song.wav")
        assert stems["guitar"].endswith(os.path.join("htdemucs", "song", "other.wav"))

    def test_separate_stems_failure_records_failed_metric(self) -> None:
        """When Demucs separation fails, default_metrics.stage_errors records the failure."""
        from unittest.mock import patch

        from monitoring import default_metrics

        before_errors = default_metrics.stage_errors.get("demucs_cli", 0)
        with (
            patch.object(
                self.splitter,
                "_separate_with_api",
                side_effect=RuntimeError("demucs failed"),
            ),
            patch.object(
                self.splitter,
                "_separate_with_subprocess",
                side_effect=RuntimeError("demucs cli failed"),
            ),
            patch.object(
                self.splitter,
                "_raw_audio_fallback",
                return_value={"guitar": "g.wav", "bass": "b.wav"},
            ),
        ):
            self.splitter.separate_stems("bad.wav")
        after_errors = default_metrics.stage_errors.get("demucs_cli", 0)
        assert after_errors == before_errors + 1

    def test_separate_with_api_honors_explicit_device(self) -> None:
        """SplitterAgent(device='cpu') passes device='cpu' to demucs_api.Separator."""
        from unittest.mock import MagicMock, patch

        import agents as _a

        sp = SplitterAgent(output_dir=self.tmpdir, device="cpu")
        mock_api = MagicMock()
        mock_sep = MagicMock()
        mock_sep.separate_audio_file.return_value = (None, {})
        mock_api.Separator.return_value = mock_sep

        with (
            patch.object(_a, "demucs_api", mock_api, create=True),
            patch("agents.torch.cuda.is_available", return_value=True),
        ):
            sp._separate_with_api("/tmp/song.wav", "song")

        assert mock_api.Separator.call_args.kwargs["device"] == "cpu"


if __name__ == "__main__":
    unittest.main()
